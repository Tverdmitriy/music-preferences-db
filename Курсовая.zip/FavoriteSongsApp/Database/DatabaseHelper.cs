﻿using MySql.Data.MySqlClient;
using System.Data;

namespace FavoriteSongsApp.Database
{
    public class DatabaseHelper
    {
        private string? connectionString;
        private static DatabaseHelper? _instance;

        public static DatabaseHelper Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new DatabaseHelper();
                return _instance;
            }
        }

        public bool IsConnected => !string.IsNullOrEmpty(connectionString);

        public void SetConnection(string server, string database, string user, string password)
        {
            connectionString = $"Server={server};Database={database};User={user};Password={password};";
        }

        private MySqlConnection GetConnection()
        {
            return new MySqlConnection(connectionString);
        }

        public DataTable ExecuteQuery(string query)
        {
            using (var connection = GetConnection())
            {
                var adapter = new MySqlDataAdapter(query, connection);
                var dataTable = new DataTable();
                adapter.Fill(dataTable);
                return dataTable;
            }
        }

        public int ExecuteNonQuery(string query)
        {
            using (var connection = GetConnection())
            {
                connection.Open();
                var command = new MySqlCommand(query, connection);
                return command.ExecuteNonQuery();
            }
        }

        public object ExecuteScalar(string query)
        {
            using (var connection = GetConnection())
            {
                connection.Open();
                var command = new MySqlCommand(query, connection);
                return command.ExecuteScalar();
            }
        }

        public DataTable ExecuteStoredProcedure(string procName, MySqlParameter[] parameters)
        {
            using (var connection = GetConnection())
            {
                var command = new MySqlCommand(procName, connection);
                command.CommandType = CommandType.StoredProcedure;
                if (parameters != null)
                    command.Parameters.AddRange(parameters);

                var adapter = new MySqlDataAdapter(command);
                var dataTable = new DataTable();
                adapter.Fill(dataTable);
                return dataTable;
            }
        }
    }
}