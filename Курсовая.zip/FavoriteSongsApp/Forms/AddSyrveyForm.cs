﻿using FavoriteSongsApp.Database;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;

namespace FavoriteSongsApp.Forms
{
    public partial class AddSurveyForm : Form
    {
        private List<int> selectedSongs = new List<int>();
        private DataTable allSongs;

        public AddSurveyForm()
        {
            InitializeComponent();
            LoadParticipants();
            LoadSongs();
        }

        private void LoadParticipants()
        {
            try
            {
                string query = @"
                    SELECT 
                        p.id_participant,
                        CONCAT(p.surname, ' (', g.value, ', ', p.age, ' лет)') AS participant_info
                    FROM Participant p
                    JOIN Gender g ON p.id_gender = g.id_gender
                    ORDER BY p.surname";

                var data = DatabaseHelper.Instance.ExecuteQuery(query);
                cmbParticipant.DataSource = data;
                cmbParticipant.DisplayMember = "participant_info";
                cmbParticipant.ValueMember = "id_participant";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки участников: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadSongs()
        {
            try
            {
                string query = @"
                    SELECT 
                        s.id_song,
                        CONCAT(s.title, ' - ', p.name) AS song_info
                    FROM Song s
                    JOIN Performer p ON s.id_performer = p.id_performer
                    ORDER BY s.title";

                allSongs = DatabaseHelper.Instance.ExecuteQuery(query);
                UpdateAvailableSongsList();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки песен: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void UpdateAvailableSongsList()
        {
            var availableSongs = allSongs.AsEnumerable()
                .Where(row => !selectedSongs.Contains(row.Field<int>("id_song")))
                .CopyToDataTable();

            lstAvailableSongs.DataSource = availableSongs;
            lstAvailableSongs.DisplayMember = "song_info";
        }

        private void btnAddSong_Click(object sender, EventArgs e)
        {
            if (lstAvailableSongs.SelectedItem == null)
            {
                MessageBox.Show("Выберите песню из списка", "Предупреждение",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (selectedSongs.Count >= 5)
            {
                MessageBox.Show("Можно выбрать не более 5 песен", "Предупреждение",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DataRowView selectedRow = (DataRowView)lstAvailableSongs.SelectedItem;
            int songId = selectedRow.Row.Field<int>("id_song");
            string songInfo = selectedRow.Row.Field<string>("song_info");

            selectedSongs.Add(songId);
            lstSelectedSongs.Items.Add($"{selectedSongs.Count}. {songInfo}");

            UpdateAvailableSongsList();
            btnRemoveSong.Enabled = true;
        }

        private void btnRemoveSong_Click(object sender, EventArgs e)
        {
            if (lstSelectedSongs.SelectedIndex == -1)
            {
                MessageBox.Show("Выберите песню для удаления", "Предупреждение",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int index = lstSelectedSongs.SelectedIndex;
            int songId = selectedSongs[index];

            selectedSongs.RemoveAt(index);
            lstSelectedSongs.Items.RemoveAt(index);

            // Перенумеровать список
            for (int i = 0; i < lstSelectedSongs.Items.Count; i++)
            {
                DataRowView row = (DataRowView)lstAvailableSongs.Items[i];
                string songInfo = row.Row.Field<string>("song_info");
                lstSelectedSongs.Items[i] = $"{i + 1}. {songInfo}";
            }

            UpdateAvailableSongsList();

            if (lstSelectedSongs.Items.Count == 0)
                btnRemoveSong.Enabled = false;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (cmbParticipant.SelectedValue == null)
            {
                MessageBox.Show("Выберите участника", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (selectedSongs.Count != 5)
            {
                MessageBox.Show("Выберите ровно 5 песен", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                int participantId = Convert.ToInt32(cmbParticipant.SelectedValue);

                // Используем хранимую процедуру sp_submit_preferences
                int idSurveyResult = SubmitPreferences(
                    participantId,
                    selectedSongs[0], 1,
                    selectedSongs[1], 2,
                    selectedSongs[2], 3,
                    selectedSongs[3], 4,
                    selectedSongs[4], 5
                );

                MessageBox.Show($"Опрос успешно сохранен!\nID результата: {idSurveyResult}", "Успех",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);

                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private int SubmitPreferences(int participantId,
            int song1, int rank1, int song2, int rank2,
            int song3, int rank3, int song4, int rank4,
            int song5, int rank5)
        {
            // Создаем результат опроса
            string insertSurvey = $@"
                INSERT INTO SurveyResult (id_participant, survey_date, is_completed)
                VALUES ({participantId}, NOW(), FALSE)";

            DatabaseHelper.Instance.ExecuteNonQuery(insertSurvey);
            int surveyId = Convert.ToInt32(DatabaseHelper.Instance.ExecuteScalar("SELECT LAST_INSERT_ID()"));

            // Добавляем предпочтения
            string insertPreferences = $@"
                INSERT INTO Preference (id_survey_result, id_song, song_rank) VALUES
                ({surveyId}, {song1}, {rank1}),
                ({surveyId}, {song2}, {rank2}),
                ({surveyId}, {song3}, {rank3}),
                ({surveyId}, {song4}, {rank4}),
                ({surveyId}, {song5}, {rank5})";

            DatabaseHelper.Instance.ExecuteNonQuery(insertPreferences);

            // Помечаем опрос как завершенный
            DatabaseHelper.Instance.ExecuteNonQuery(
                $"UPDATE SurveyResult SET is_completed = TRUE WHERE id_survey_result = {surveyId}");

            return surveyId;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
}