﻿namespace FavoriteSongsApp.Forms
{
    partial class AnalyticsForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.dgvAnalytics = new System.Windows.Forms.DataGridView();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.btnByCategory = new System.Windows.Forms.Button();
            this.btnTopSongs = new System.Windows.Forms.Button();
            this.lblTitle = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAnalytics)).BeginInit();
            this.SuspendLayout();

            // dgvAnalytics
            this.dgvAnalytics.AllowUserToAddRows = false;
            this.dgvAnalytics.AllowUserToDeleteRows = false;
            this.dgvAnalytics.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvAnalytics.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvAnalytics.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAnalytics.Location = new System.Drawing.Point(12, 50);
            this.dgvAnalytics.MultiSelect = false;
            this.dgvAnalytics.Name = "dgvAnalytics";
            this.dgvAnalytics.ReadOnly = true;
            this.dgvAnalytics.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvAnalytics.Size = new System.Drawing.Size(760, 350);
            this.dgvAnalytics.TabIndex = 0;

            // btnRefresh
            this.btnRefresh.Location = new System.Drawing.Point(12, 12);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(100, 30);
            this.btnRefresh.TabIndex = 1;
            this.btnRefresh.Text = "🔄 Популярность";
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);

            // btnByCategory
            this.btnByCategory.Location = new System.Drawing.Point(118, 12);
            this.btnByCategory.Name = "btnByCategory";
            this.btnByCategory.Size = new System.Drawing.Size(150, 30);
            this.btnByCategory.TabIndex = 2;
            this.btnByCategory.Text = "📊 По категориям";
            this.btnByCategory.UseVisualStyleBackColor = true;
            this.btnByCategory.Click += new System.EventHandler(this.btnByCategory_Click);

            // btnTopSongs
            this.btnTopSongs.Location = new System.Drawing.Point(274, 12);
            this.btnTopSongs.Name = "btnTopSongs";
            this.btnTopSongs.Size = new System.Drawing.Size(150, 30);
            this.btnTopSongs.TabIndex = 3;
            this.btnTopSongs.Text = "🏆 Топ по категориям";
            this.btnTopSongs.UseVisualStyleBackColor = true;
            this.btnTopSongs.Click += new System.EventHandler(this.btnTopSongs_Click);

            // lblTitle
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblTitle.Location = new System.Drawing.Point(450, 15);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(180, 20);
            this.lblTitle.TabIndex = 4;
            this.lblTitle.Text = "Аналитика опросов";

            // AnalyticsForm
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 412);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.btnTopSongs);
            this.Controls.Add(this.btnByCategory);
            this.Controls.Add(this.btnRefresh);
            this.Controls.Add(this.dgvAnalytics);
            this.Name = "AnalyticsForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Аналитика - Любимые песни";
            ((System.ComponentModel.ISupportInitialize)(this.dgvAnalytics)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.DataGridView dgvAnalytics;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.Button btnByCategory;
        private System.Windows.Forms.Button btnTopSongs;
        private System.Windows.Forms.Label lblTitle;
    }
}