﻿using FavoriteSongsApp.Database;
using System;
using System.Windows.Forms;

namespace FavoriteSongsApp.Forms
{
    public partial class AddParticipantForm : Form
    {
        public AddParticipantForm()
        {
            InitializeComponent();
            LoadGenderAndAgeCategories();
        }

        private void LoadGenderAndAgeCategories()
        {
            try
            {
                // Загрузка полов
                string genderQuery = "SELECT id_gender, value FROM Gender";
                var genderData = DatabaseHelper.Instance.ExecuteQuery(genderQuery);
                cmbGender.DataSource = genderData;
                cmbGender.DisplayMember = "value";
                cmbGender.ValueMember = "id_gender";

                // Загрузка возрастных категорий
                string ageQuery = "SELECT id_age_category, range_label FROM AgeCategory";
                var ageData = DatabaseHelper.Instance.ExecuteQuery(ageQuery);
                cmbAgeCategory.DataSource = ageData;
                cmbAgeCategory.DisplayMember = "range_label";
                cmbAgeCategory.ValueMember = "id_age_category";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки данных: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            // Проверка обязательных полей
            if (string.IsNullOrWhiteSpace(txtSurname.Text))
            {
                MessageBox.Show("Введите фамилию участника", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtSurname.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(txtAge.Text))
            {
                MessageBox.Show("Введите возраст", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtAge.Focus();
                return;
            }

            int age;
            if (!int.TryParse(txtAge.Text, out age) || age < 1 || age > 150)
            {
                MessageBox.Show("Возраст должен быть числом от 1 до 150", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtAge.Focus();
                return;
            }

            try
            {
                int idGender = Convert.ToInt32(cmbGender.SelectedValue);
                int idAgeCategory = Convert.ToInt32(cmbAgeCategory.SelectedValue);

                // Вставка нового участника
                string query = $@"
                    INSERT INTO Participant (surname, id_gender, age, id_age_category, contact_info)
                    VALUES ('{txtSurname.Text}', {idGender}, {age}, {idAgeCategory}, '{txtContact.Text}')";

                DatabaseHelper.Instance.ExecuteNonQuery(query);

                MessageBox.Show("Участник успешно добавлен!", "Успех",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);

                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при добавлении участника: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
}