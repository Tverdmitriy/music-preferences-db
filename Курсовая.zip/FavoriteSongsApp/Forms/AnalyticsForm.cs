﻿using FavoriteSongsApp.Database;
using System;
using System.Windows.Forms;

namespace FavoriteSongsApp.Forms
{
    public partial class AnalyticsForm : Form
    {
        public AnalyticsForm()
        {
            InitializeComponent();
            LoadPopularity();
        }

        private void LoadPopularity()
        {
            try
            {
                // Используем представление v_song_popularity
                string query = "SELECT * FROM v_song_popularity LIMIT 20";
                dgvAnalytics.DataSource = DatabaseHelper.Instance.ExecuteQuery(query);
                dgvAnalytics.AutoResizeColumns();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnByCategory_Click(object sender, EventArgs e)
        {
            try
            {
                // Анализ по демографическим категориям
                string query = @"
                    SELECT 
                        population_category AS 'Категория',
                        song_title AS 'Песня',
                        performer AS 'Исполнитель',
                        votes AS 'Голоса',
                        avg_rank AS 'Сред. ранг'
                    FROM v_demographic_analysis
                    LIMIT 50";

                dgvAnalytics.DataSource = DatabaseHelper.Instance.ExecuteQuery(query);
                dgvAnalytics.AutoResizeColumns();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnTopSongs_Click(object sender, EventArgs e)
        {
            try
            {
                // Топ песен по категориям
                string query = @"
                    SELECT 
                        population_category AS 'Категория',
                        song_title AS 'Песня',
                        performer AS 'Исполнитель',
                        votes AS 'Голоса',
                        rank_in_category AS 'Место'
                    FROM v_top_songs_by_category
                    ORDER BY population_category, rank_in_category";

                dgvAnalytics.DataSource = DatabaseHelper.Instance.ExecuteQuery(query);
                dgvAnalytics.AutoResizeColumns();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadPopularity();
        }
    }
}