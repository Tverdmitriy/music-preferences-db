﻿using FavoriteSongsApp.Database;
using System;
using System.Windows.Forms;

namespace FavoriteSongsApp.Forms
{
    public partial class ParticipantsForm : Form
    {
        public ParticipantsForm()
        {
            InitializeComponent();
            LoadData();
        }

        private void LoadData()
        {
            try
            {
                string query = @"
                    SELECT 
                        p.id_participant AS 'ID',
                        p.surname AS 'Фамилия',
                        g.value AS 'Пол',
                        p.age AS 'Возраст',
                        ac.range_label AS 'Возрастная категория',
                        p.contact_info AS 'Контакты'
                    FROM Participant p
                    JOIN Gender g ON p.id_gender = g.id_gender
                    JOIN AgeCategory ac ON p.id_age_category = ac.id_age_category
                    ORDER BY p.id_participant";

                dgvParticipants.DataSource = DatabaseHelper.Instance.ExecuteQuery(query);
                dgvParticipants.AutoResizeColumns();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadData();
        }

        private void btnAddParticipant_Click(object sender, EventArgs e)
        {
            var addForm = new AddParticipantForm();
            if (addForm.ShowDialog() == DialogResult.OK)
            {
                LoadData();
            }
        }
    }
}