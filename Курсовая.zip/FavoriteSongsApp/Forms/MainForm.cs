﻿using FavoriteSongsApp.Database;
using Org.BouncyCastle.Asn1.Cmp;
using System;
using System.Windows.Forms;

namespace FavoriteSongsApp.Forms
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
            CheckConnection();
        }

        private void CheckConnection()
        {
            if (!DatabaseHelper.Instance.IsConnected)
            {
                var connectionForm = new ConnectionForm();
                if (connectionForm.ShowDialog() == DialogResult.OK)
                {
                    lblStatus.Text = "✓ Подключено к БД";
                    lblStatus.ForeColor = System.Drawing.Color.Green;
                }
                else
                {
                    Application.Exit();
                }
            }
            else
            {
                lblStatus.Text = "✓ Подключено к БД";
                lblStatus.ForeColor = System.Drawing.Color.Green;
            }
        }

        private void btnSongs_Click(object sender, EventArgs e)
        {
            var form = new SongsForm();
            form.ShowDialog();
        }

        private void btnParticipants_Click(object sender, EventArgs e)
        {
            var form = new ParticipantsForm();
            form.ShowDialog();
        }

        private void btnSurveys_Click(object sender, EventArgs e)
        {
            var form = new SurveyForm();
            form.ShowDialog();
        }

        private void btnAnalytics_Click(object sender, EventArgs e)
        {
            var form = new AnalyticsForm();
            form.ShowDialog();
        }

        private void btnRecords_Click(object sender, EventArgs e)
        {
            var form = new RecordsForm();
            form.ShowDialog();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}