﻿namespace FavoriteSongsApp.Forms
{
    partial class AddSurveyForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblParticipant = new System.Windows.Forms.Label();
            this.lblAvailableSongs = new System.Windows.Forms.Label();
            this.lblSelectedSongs = new System.Windows.Forms.Label();
            this.cmbParticipant = new System.Windows.Forms.ComboBox();
            this.lstAvailableSongs = new System.Windows.Forms.ListBox();
            this.lstSelectedSongs = new System.Windows.Forms.ListBox();
            this.btnAddSong = new System.Windows.Forms.Button();
            this.btnRemoveSong = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblInfo = new System.Windows.Forms.Label();
            this.SuspendLayout();

            // lblTitle
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.lblTitle.Location = new System.Drawing.Point(12, 15);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(280, 20);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Добавление результатов опроса";

            // lblParticipant
            this.lblParticipant.AutoSize = true;
            this.lblParticipant.Location = new System.Drawing.Point(15, 50);
            this.lblParticipant.Name = "lblParticipant";
            this.lblParticipant.Size = new System.Drawing.Size(65, 13);
            this.lblParticipant.TabIndex = 1;
            this.lblParticipant.Text = "Участник:";

            // cmbParticipant
            this.cmbParticipant.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbParticipant.FormattingEnabled = true;
            this.cmbParticipant.Location = new System.Drawing.Point(15, 70);
            this.cmbParticipant.Name = "cmbParticipant";
            this.cmbParticipant.Size = new System.Drawing.Size(300, 21);
            this.cmbParticipant.TabIndex = 2;

            // lblInfo
            this.lblInfo.AutoSize = true;
            this.lblInfo.ForeColor = System.Drawing.Color.Blue;
            this.lblInfo.Location = new System.Drawing.Point(15, 100);
            this.lblInfo.Name = "lblInfo";
            this.lblInfo.Size = new System.Drawing.Size(250, 13);
            this.lblInfo.TabIndex = 3;
            this.lblInfo.Text = "Выберите 5 любимых песен в порядке предпочтения:";

            // lblAvailableSongs
            this.lblAvailableSongs.AutoSize = true;
            this.lblAvailableSongs.Location = new System.Drawing.Point(15, 125);
            this.lblAvailableSongs.Name = "lblAvailableSongs";
            this.lblAvailableSongs.Size = new System.Drawing.Size(130, 13);
            this.lblAvailableSongs.TabIndex = 4;
            this.lblAvailableSongs.Text = "Доступные песни:";

            // lstAvailableSongs
            this.lstAvailableSongs.FormattingEnabled = true;
            this.lstAvailableSongs.Location = new System.Drawing.Point(15, 145);
            this.lstAvailableSongs.Name = "lstAvailableSongs";
            this.lstAvailableSongs.Size = new System.Drawing.Size(300, 225);
            this.lstAvailableSongs.TabIndex = 5;

            // lblSelectedSongs
            this.lblSelectedSongs.AutoSize = true;
            this.lblSelectedSongs.Location = new System.Drawing.Point(340, 125);
            this.lblSelectedSongs.Name = "lblSelectedSongs";
            this.lblSelectedSongs.Size = new System.Drawing.Size(130, 13);
            this.lblSelectedSongs.TabIndex = 6;
            this.lblSelectedSongs.Text = "Выбранные песни (0/5):";

            // lstSelectedSongs
            this.lstSelectedSongs.FormattingEnabled = true;
            this.lstSelectedSongs.Location = new System.Drawing.Point(340, 145);
            this.lstSelectedSongs.Name = "lstSelectedSongs";
            this.lstSelectedSongs.Size = new System.Drawing.Size(300, 225);
            this.lstSelectedSongs.TabIndex = 7;

            // btnAddSong
            this.btnAddSong.Location = new System.Drawing.Point(15, 380);
            this.btnAddSong.Name = "btnAddSong";
            this.btnAddSong.Size = new System.Drawing.Size(140, 30);
            this.btnAddSong.TabIndex = 8;
            this.btnAddSong.Text = "➕ Добавить песню";
            this.btnAddSong.UseVisualStyleBackColor = true;
            this.btnAddSong.Click += new System.EventHandler(this.btnAddSong_Click);

            // btnRemoveSong
            this.btnRemoveSong.Enabled = false;
            this.btnRemoveSong.Location = new System.Drawing.Point(175, 380);
            this.btnRemoveSong.Name = "btnRemoveSong";
            this.btnRemoveSong.Size = new System.Drawing.Size(140, 30);
            this.btnRemoveSong.TabIndex = 9;
            this.btnRemoveSong.Text = "❌ Удалить песню";
            this.btnRemoveSong.UseVisualStyleBackColor = true;
            this.btnRemoveSong.Click += new System.EventHandler(this.btnRemoveSong_Click);

            // btnSave
            this.btnSave.Location = new System.Drawing.Point(450, 380);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(90, 30);
            this.btnSave.TabIndex = 10;
            this.btnSave.Text = "💾 Сохранить";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);

            // btnCancel
            this.btnCancel.Location = new System.Drawing.Point(550, 380);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(90, 30);
            this.btnCancel.TabIndex = 11;
            this.btnCancel.Text = "❌ Отмена";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);

            // AddSurveyForm
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(660, 430);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnRemoveSong);
            this.Controls.Add(this.btnAddSong);
            this.Controls.Add(this.lstSelectedSongs);
            this.Controls.Add(this.lblSelectedSongs);
            this.Controls.Add(this.lstAvailableSongs);
            this.Controls.Add(this.lblAvailableSongs);
            this.Controls.Add(this.lblInfo);
            this.Controls.Add(this.cmbParticipant);
            this.Controls.Add(this.lblParticipant);
            this.Controls.Add(this.lblTitle);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "AddSurveyForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Добавление результатов опроса";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblParticipant;
        private System.Windows.Forms.Label lblAvailableSongs;
        private System.Windows.Forms.Label lblSelectedSongs;
        private System.Windows.Forms.ComboBox cmbParticipant;
        private System.Windows.Forms.ListBox lstAvailableSongs;
        private System.Windows.Forms.ListBox lstSelectedSongs;
        private System.Windows.Forms.Button btnAddSong;
        private System.Windows.Forms.Button btnRemoveSong;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Label lblInfo;
    }
}