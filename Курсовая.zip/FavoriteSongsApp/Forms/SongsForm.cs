﻿using FavoriteSongsApp.Database;
using System;
using System.Windows.Forms;

namespace FavoriteSongsApp.Forms
{
    public partial class SongsForm : Form
    {
        public SongsForm()
        {
            InitializeComponent();
            LoadData();
        }

        private void LoadData()
        {
            try
            {
                string query = @"
                    SELECT 
                        s.id_song AS 'ID',
                        s.title AS 'Название',
                        p.name AS 'Исполнитель',
                        s.genre AS 'Жанр',
                        s.release_year AS 'Год',
                        s.duration_sec AS 'Длительность (сек)'
                    FROM Song s
                    JOIN Performer p ON s.id_performer = p.id_performer
                    ORDER BY s.id_song";

                dgvSongs.DataSource = DatabaseHelper.Instance.ExecuteQuery(query);
                dgvSongs.AutoResizeColumns();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadData();
        }

        private void btnAddSong_Click(object sender, EventArgs e)
        {
            // Простая форма добавления через InputBox
            string title = Microsoft.VisualBasic.Interaction.InputBox("Введите название песни:", "Добавить песню");
            if (string.IsNullOrWhiteSpace(title)) return;

            string performer = Microsoft.VisualBasic.Interaction.InputBox("Введите имя исполнителя:", "Добавить песню");
            if (string.IsNullOrWhiteSpace(performer)) return;

            try
            {
                // Сначала проверяем, существует ли исполнитель
                var checkQuery = $"SELECT id_performer FROM Performer WHERE name = '{performer}'";
                var result = DatabaseHelper.Instance.ExecuteScalar(checkQuery);

                int performerId;
                if (result == null)
                {
                    // Создаем нового исполнителя
                    string insertPerformer = $"INSERT INTO Performer (name) VALUES ('{performer}')";
                    DatabaseHelper.Instance.ExecuteNonQuery(insertPerformer);
                    performerId = Convert.ToInt32(DatabaseHelper.Instance.ExecuteScalar("SELECT LAST_INSERT_ID()"));
                }
                else
                {
                    performerId = Convert.ToInt32(result);
                }

                // Получаем следующий ID песни
                int songId = Convert.ToInt32(DatabaseHelper.Instance.ExecuteScalar("SELECT COALESCE(MAX(id_song), 0) + 1 FROM Song"));

                // Добавляем песню
                string insertSong = $"INSERT INTO Song (id_song, title, id_performer) VALUES ({songId}, '{title}', {performerId})";
                DatabaseHelper.Instance.ExecuteNonQuery(insertSong);

                MessageBox.Show("Песня успешно добавлена!", "Успех",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);

                LoadData();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnAddPerformer_Click(object sender, EventArgs e)
        {
            string performer = Microsoft.VisualBasic.Interaction.InputBox("Введите имя исполнителя:", "Добавить исполнителя");
            if (string.IsNullOrWhiteSpace(performer)) return;

            try
            {
                string query = $"INSERT INTO Performer (name) VALUES ('{performer}')";
                DatabaseHelper.Instance.ExecuteNonQuery(query);

                MessageBox.Show("Исполнитель успешно добавлен!", "Успех",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);

                LoadData();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}