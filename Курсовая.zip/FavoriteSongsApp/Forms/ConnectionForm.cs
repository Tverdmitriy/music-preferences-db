﻿using FavoriteSongsApp.Database;
using Org.BouncyCastle.Tls;
using System;
using System.Windows.Forms;

namespace FavoriteSongsApp.Forms
{
    public partial class ConnectionForm : Form
    {
        public ConnectionForm()
        {
            InitializeComponent();
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            try
            {
                DatabaseHelper.Instance.SetConnection(
                    txtServer.Text,
                    txtDatabase.Text,
                    txtUser.Text,
                    txtPassword.Text
                );

                // Проверка подключения
                DatabaseHelper.Instance.ExecuteQuery("SELECT 1");

                MessageBox.Show("Подключение успешно!", "Успех",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка подключения: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
}