﻿using FavoriteSongsApp.Database;
using System;
using System.Windows.Forms;

namespace FavoriteSongsApp.Forms
{
    public partial class SurveyForm : Form
    {
        public SurveyForm()
        {
            InitializeComponent();
            LoadData();
        }

        private void LoadData()
        {
            try
            {
                string query = @"
                    SELECT 
                        sr.id_survey_result AS 'ID опроса',
                        p.surname AS 'Фамилия',
                        CONCAT(g.value, ', ', ac.range_label) AS 'Категория',
                        sr.survey_date AS 'Дата опроса',
                        CASE WHEN sr.is_completed = 1 THEN 'Завершён' ELSE 'В процессе' END AS 'Статус'
                    FROM SurveyResult sr
                    JOIN Participant p ON sr.id_participant = p.id_participant
                    JOIN Gender g ON p.id_gender = g.id_gender
                    JOIN AgeCategory ac ON p.id_age_category = ac.id_age_category
                    ORDER BY sr.survey_date DESC";

                dgvSurveys.DataSource = DatabaseHelper.Instance.ExecuteQuery(query);
                dgvSurveys.AutoResizeColumns();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadData();
        }

        private void btnAddSurvey_Click(object sender, EventArgs e)
        {
            var addForm = new AddSurveyForm();
            if (addForm.ShowDialog() == DialogResult.OK)
            {
                LoadData();
            }
        }
    }
}