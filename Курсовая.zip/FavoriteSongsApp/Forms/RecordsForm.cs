﻿using FavoriteSongsApp.Database;
using MySql.Data.MySqlClient;
using System;
using System.Windows.Forms;

namespace FavoriteSongsApp.Forms
{
    public partial class RecordsForm : Form
    {
        public RecordsForm()
        {
            InitializeComponent();
            LoadRecords();
            LoadCategories();
        }

        private void LoadRecords()
        {
            try
            {
                string query = @"
                    SELECT 
                        r.id_record AS 'ID',
                        r.title AS 'Название',
                        r.release_date AS 'Дата выпуска',
                        r.target_category AS 'Целевая аудитория',
                        CASE WHEN r.is_active = 1 THEN 'Активна' ELSE 'Архив' END AS 'Статус'
                    FROM Record r
                    ORDER BY r.id_record";

                dgvRecords.DataSource = DatabaseHelper.Instance.ExecuteQuery(query);
                dgvRecords.AutoResizeColumns();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadCategories()
        {
            try
            {
                string query = "SELECT id_population_category, label FROM PopulationCategory";
                var dt = DatabaseHelper.Instance.ExecuteQuery(query);

                cmbCategory.DataSource = dt;
                cmbCategory.DisplayMember = "label";
                cmbCategory.ValueMember = "id_population_category";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCreateRecord_Click(object sender, EventArgs e)
        {
            try
            {
                // Вызов хранимой процедуры sp_create_record_from_top_songs
                var parameters = new MySqlParameter[]
                {
                    new MySqlParameter("p_record_title", txtRecordTitle.Text),
                    new MySqlParameter("p_target_category", txtTargetCategory.Text),
                    new MySqlParameter("p_top_n", 5),
                    new MySqlParameter("p_id_gender", 1), // Пример: мужчины
                    new MySqlParameter("p_id_age_category", 2) // Пример: 20+
                };

                var result = DatabaseHelper.Instance.ExecuteStoredProcedure(
                    "sp_create_record_from_top_songs", parameters);

                MessageBox.Show("Пластинка успешно создана!", "Успех",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);

                LoadRecords();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnViewComposition_Click(object sender, EventArgs e)
        {
            try
            {
                if (dgvRecords.CurrentRow == null) return;

                int idRecord = Convert.ToInt32(dgvRecords.CurrentRow.Cells["ID"].Value);

                string query = $@"
                    SELECT 
                        rc.track_order AS '№',
                        s.title AS 'Песня',
                        p.name AS 'Исполнитель',
                        s.genre AS 'Жанр'
                    FROM RecordComposition rc
                    JOIN Song s ON rc.id_song = s.id_song
                    JOIN Performer p ON s.id_performer = p.id_performer
                    WHERE rc.id_record = {idRecord}
                    ORDER BY rc.track_order";

                var compositionForm = new Form();
                compositionForm.Text = "Состав пластинки";
                compositionForm.Size = new System.Drawing.Size(600, 400);

                var dgv = new DataGridView();
                dgv.Dock = DockStyle.Fill;
                dgv.DataSource = DatabaseHelper.Instance.ExecuteQuery(query);
                dgv.AutoResizeColumns();

                compositionForm.Controls.Add(dgv);
                compositionForm.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadRecords();
        }
    }
}