﻿namespace FavoriteSongsApp.Forms
{
    partial class RecordsForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.dgvRecords = new System.Windows.Forms.DataGridView();
            this.cmbCategory = new System.Windows.Forms.ComboBox();
            this.txtRecordTitle = new System.Windows.Forms.TextBox();
            this.txtTargetCategory = new System.Windows.Forms.TextBox();
            this.btnCreateRecord = new System.Windows.Forms.Button();
            this.btnViewComposition = new System.Windows.Forms.Button();
            this.btnRefresh = new System.Windows.Forms.Button();
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblCategory = new System.Windows.Forms.Label();
            this.lblRecordTitle = new System.Windows.Forms.Label();
            this.lblTargetCategory = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRecords)).BeginInit();
            this.SuspendLayout();

            // dgvRecords
            this.dgvRecords.AllowUserToAddRows = false;
            this.dgvRecords.AllowUserToDeleteRows = false;
            this.dgvRecords.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvRecords.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvRecords.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRecords.Location = new System.Drawing.Point(12, 150);
            this.dgvRecords.MultiSelect = false;
            this.dgvRecords.Name = "dgvRecords";
            this.dgvRecords.ReadOnly = true;
            this.dgvRecords.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvRecords.Size = new System.Drawing.Size(760, 350);
            this.dgvRecords.TabIndex = 6;

            // cmbCategory
            this.cmbCategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCategory.Location = new System.Drawing.Point(150, 50);
            this.cmbCategory.Name = "cmbCategory";
            this.cmbCategory.Size = new System.Drawing.Size(200, 21);
            this.cmbCategory.TabIndex = 1;

            // txtRecordTitle
            this.txtRecordTitle.Location = new System.Drawing.Point(150, 80);
            this.txtRecordTitle.Name = "txtRecordTitle";
            this.txtRecordTitle.Size = new System.Drawing.Size(200, 20);
            this.txtRecordTitle.TabIndex = 2;

            // txtTargetCategory
            this.txtTargetCategory.Location = new System.Drawing.Point(150, 110);
            this.txtTargetCategory.Name = "txtTargetCategory";
            this.txtTargetCategory.Size = new System.Drawing.Size(200, 20);
            this.txtTargetCategory.TabIndex = 3;

            // btnCreateRecord
            this.btnCreateRecord.Location = new System.Drawing.Point(400, 45);
            this.btnCreateRecord.Name = "btnCreateRecord";
            this.btnCreateRecord.Size = new System.Drawing.Size(180, 30);
            this.btnCreateRecord.TabIndex = 4;
            this.btnCreateRecord.Text = "💿 Создать пластинку (Топ-5)";
            this.btnCreateRecord.UseVisualStyleBackColor = true;
            this.btnCreateRecord.Click += new System.EventHandler(this.btnCreateRecord_Click);

            // btnViewComposition
            this.btnViewComposition.Location = new System.Drawing.Point(400, 85);
            this.btnViewComposition.Name = "btnViewComposition";
            this.btnViewComposition.Size = new System.Drawing.Size(180, 30);
            this.btnViewComposition.TabIndex = 5;
            this.btnViewComposition.Text = "📋 Состав пластинки";
            this.btnViewComposition.UseVisualStyleBackColor = true;
            this.btnViewComposition.Click += new System.EventHandler(this.btnViewComposition_Click);

            // btnRefresh
            this.btnRefresh.Location = new System.Drawing.Point(400, 125);
            this.btnRefresh.Name = "btnRefresh";
            this.btnRefresh.Size = new System.Drawing.Size(180, 30);
            this.btnRefresh.TabIndex = 6;
            this.btnRefresh.Text = "🔄 Обновить";
            this.btnRefresh.UseVisualStyleBackColor = true;
            this.btnRefresh.Click += new System.EventHandler(this.btnRefresh_Click);

            // lblTitle
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblTitle.Location = new System.Drawing.Point(12, 15);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(100, 20);
            this.lblTitle.TabIndex = 7;
            this.lblTitle.Text = "Пластинки";

            // lblCategory
            this.lblCategory.AutoSize = true;
            this.lblCategory.Location = new System.Drawing.Point(12, 53);
            this.lblCategory.Name = "lblCategory";
            this.lblCategory.Size = new System.Drawing.Size(130, 13);
            this.lblCategory.TabIndex = 8;
            this.lblCategory.Text = "Категория населения:";

            // lblRecordTitle
            this.lblRecordTitle.AutoSize = true;
            this.lblRecordTitle.Location = new System.Drawing.Point(12, 83);
            this.lblRecordTitle.Name = "lblRecordTitle";
            this.lblRecordTitle.Size = new System.Drawing.Size(120, 13);
            this.lblRecordTitle.TabIndex = 9;
            this.lblRecordTitle.Text = "Название пластинки:";

            // lblTargetCategory
            this.lblTargetCategory.AutoSize = true;
            this.lblTargetCategory.Location = new System.Drawing.Point(12, 113);
            this.lblTargetCategory.Name = "lblTargetCategory";
            this.lblTargetCategory.Size = new System.Drawing.Size(110, 13);
            this.lblTargetCategory.TabIndex = 10;
            this.lblTargetCategory.Text = "Целевая аудитория:";

            // RecordsForm
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 512);
            this.Controls.Add(this.lblTargetCategory);
            this.Controls.Add(this.lblRecordTitle);
            this.Controls.Add(this.lblCategory);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.btnRefresh);
            this.Controls.Add(this.btnViewComposition);
            this.Controls.Add(this.btnCreateRecord);
            this.Controls.Add(this.txtTargetCategory);
            this.Controls.Add(this.txtRecordTitle);
            this.Controls.Add(this.cmbCategory);
            this.Controls.Add(this.dgvRecords);
            this.Name = "RecordsForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Пластинки - Любимые песни";
            ((System.ComponentModel.ISupportInitialize)(this.dgvRecords)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.DataGridView dgvRecords;
        private System.Windows.Forms.ComboBox cmbCategory;
        private System.Windows.Forms.TextBox txtRecordTitle;
        private System.Windows.Forms.TextBox txtTargetCategory;
        private System.Windows.Forms.Button btnCreateRecord;
        private System.Windows.Forms.Button btnViewComposition;
        private System.Windows.Forms.Button btnRefresh;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblCategory;
        private System.Windows.Forms.Label lblRecordTitle;
        private System.Windows.Forms.Label lblTargetCategory;
    }
}